package lobanovich.michael.kursach;

public class FakeMain {
    public static void main(String[] args) {
        SudokuApplication.main(args);
    }
}
